export class ProductsUrl {
  static productsUrl = '/products';
}
