export class Promo {
  public preHeading?: string;
  public heading: string;
  public afterHeading?: string;
  public imageUrl: string;
  public buttonText?: string;
  public link?: string;
}
