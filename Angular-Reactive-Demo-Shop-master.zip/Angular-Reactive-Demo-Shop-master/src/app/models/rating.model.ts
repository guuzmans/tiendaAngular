export class Rating {
  public userUid: string;
  public rating: number;
}
